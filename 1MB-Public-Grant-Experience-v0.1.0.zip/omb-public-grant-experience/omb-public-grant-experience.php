<?php
/**
 * Plugin Name: 1MB Public Grant Experience
 * Description: Adds a protected 1MBPUBLIC Treasury grant panel to the Master Command Center without creating a parallel Treasury.
 * Version: 0.1.0
 * Author: ACE
 */

if (!defined('ABSPATH')) { exit; }

define('OMB_PGE_VERSION', '0.1.0');

define('OMB_PGE_PUBLIC_CODE', '1MBPUBLIC');

register_activation_hook(__FILE__, function () {
    update_option('omb_public_grant_experience_version', OMB_PGE_VERSION, false);
});

function omb_pge_money($value, $decimals = 2) {
    return '$' . number_format((float) $value, $decimals);
}

function omb_pge_public_members() {
    return get_users([
        'meta_key'   => 'omb_company_code',
        'meta_value' => OMB_PGE_PUBLIC_CODE,
        'orderby'    => 'display_name',
        'order'      => 'ASC',
        'fields'     => ['ID', 'display_name', 'user_email'],
    ]);
}

function omb_pge_quote() {
    $quote = get_option('omb_boost_verified_quote_v1', []);
    return is_array($quote) ? $quote : [];
}

function omb_pge_pool() {
    $pool = get_option('omb_public_rewards_pool_v1', []);
    return is_array($pool) ? $pool : [];
}

function omb_pge_fifo_basis(&$lots, $coins) {
    $need = max(0.0, (float) $coins);
    $basis = 0.0;
    $covered = 0.0;

    foreach ($lots as $i => $lot) {
        if ($need <= 0) { break; }
        if (!is_array($lot)) { continue; }

        $remaining = isset($lot['remaining_coins']) ? (float) $lot['remaining_coins'] : (isset($lot['coins']) ? (float) $lot['coins'] : 0.0);
        if ($remaining <= 0) { continue; }

        $take = min($need, $remaining);
        $price = isset($lot['price']) ? (float) $lot['price'] : 0.0;
        $basis += $take * $price;
        $covered += $take;
        $remaining -= $take;
        $need -= $take;
        $lots[$i]['remaining_coins'] = max(0.0, $remaining);
    }

    return [
        'basis_usd' => $basis,
        'covered_coins' => $covered,
        'uncovered_coins' => max(0.0, (float) $coins - $covered),
    ];
}

function omb_pge_notice_html() {
    if (empty($_GET['omb_public_grant'])) { return ''; }
    $status = sanitize_key(wp_unslash($_GET['omb_public_grant']));
    $messages = [
        'success' => ['good', 'Public BOOST grant recorded successfully.'],
        'invalid_recipient' => ['bad', 'That recipient is not an active 1MBPUBLIC member.'],
        'invalid_amount' => ['bad', 'Enter a BOOST amount greater than zero.'],
        'insufficient_pool' => ['bad', 'The public reward pool does not have enough BOOST for that grant.'],
        'missing_quote' => ['bad', 'A verified BOOST reference quote is required before recording a grant.'],
        'security' => ['bad', 'Security validation failed. Please try again.'],
    ];
    if (!isset($messages[$status])) { return ''; }
    [$class, $message] = $messages[$status];
    return '<div class="omb-pge-notice ' . esc_attr($class) . '">' . esc_html($message) . '</div>';
}

function omb_pge_panel() {
    if (!is_user_logged_in() || !current_user_can('manage_options')) { return ''; }

    $pool = omb_pge_pool();
    $quote = omb_pge_quote();
    $members = omb_pge_public_members();
    $grants = get_option('omb_public_reward_grants_v1', []);
    if (!is_array($grants)) { $grants = []; }

    $pool_coins = isset($pool['coins']) ? (float) $pool['coins'] : 0.0;
    $price = isset($quote['price']) ? (float) $quote['price'] : 0.0;
    $source = isset($quote['source']) ? (string) $quote['source'] : 'Verified reference';
    $pool_value = $pool_coins * $price;
    $recent = array_slice(array_reverse($grants), 0, 8);

    ob_start();
    ?>
    <section class="omb-pge-wrap" id="public-grants">
      <style>
        .omb-pge-wrap{max-width:1180px;margin:18px auto 0;padding:0 18px 52px;color:#f7fbff;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
        .omb-pge-panel{background:linear-gradient(145deg,#07131d,#0c1d29);border:1px solid #2b485a;border-radius:22px;padding:22px;box-shadow:0 22px 60px rgba(0,0,0,.25)}
        .omb-pge-kicker{font-size:11px;letter-spacing:.15em;text-transform:uppercase;color:#b7ff36;font-weight:950}
        .omb-pge-panel h2{margin:7px 0 6px;color:#fff;font-size:clamp(28px,4vw,40px);line-height:1.05}
        .omb-pge-panel>p{margin:0;color:#93a9b8;max-width:820px;line-height:1.5}
        .omb-pge-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:11px;margin:18px 0}
        .omb-pge-stat{background:#091720;border:1px solid #263f50;border-radius:15px;padding:14px}
        .omb-pge-label{font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:#8299aa;font-weight:900}
        .omb-pge-value{margin-top:5px;color:#fff;font-size:25px;font-weight:950;word-break:break-word}
        .omb-pge-value.green{color:#b7ff36}
        .omb-pge-sub{margin-top:4px;font-size:11px;color:#7f96a6}
        .omb-pge-form{display:grid;grid-template-columns:1.4fr .75fr 1.2fr auto;gap:11px;align-items:end;margin-top:14px}
        .omb-pge-form label{display:block;color:#91a8b8;font-size:10px;letter-spacing:.08em;text-transform:uppercase;font-weight:900}
        .omb-pge-form select,.omb-pge-form input{width:100%;box-sizing:border-box;min-height:46px;margin-top:6px;border:1px solid #355367;border-radius:10px;background:#07131d;color:#fff;padding:10px 12px;font-size:15px}
        .omb-pge-form select{background:#fff;color:#111}
        .omb-pge-form button{min-height:46px;border:0;border-radius:11px;background:#b7ff36;color:#071007;font-weight:950;padding:0 18px;cursor:pointer;white-space:nowrap}
        .omb-pge-help{margin-top:10px;color:#7890a0;font-size:11px;line-height:1.45}
        .omb-pge-help a{color:#c9ff72!important;font-weight:850}
        .omb-pge-notice{margin:14px 0;padding:12px 14px;border-radius:11px;font-weight:800}
        .omb-pge-notice.good{background:#122b18;border:1px solid #4f7930;color:#ddffad}
        .omb-pge-notice.bad{background:#2d171b;border:1px solid #75404a;color:#ffdce1}
        .omb-pge-history{margin-top:20px;border-top:1px solid #263f50;padding-top:18px}
        .omb-pge-history h3{margin:0 0 10px;color:#fff;font-size:19px}
        .omb-pge-tablewrap{overflow-x:auto;border:1px solid #263f50;border-radius:12px}
        .omb-pge-table{width:100%;border-collapse:collapse;min-width:760px;background:#091720}
        .omb-pge-table th,.omb-pge-table td{padding:11px 12px;border-bottom:1px solid #203543;text-align:left;font-size:12px;color:#eaf4fa}
        .omb-pge-table th{font-size:9px;text-transform:uppercase;letter-spacing:.08em;color:#8198a8;background:#10222e}
        .omb-pge-table tr:last-child td{border-bottom:0}
        .omb-pge-empty{padding:14px;color:#8298a8}
        body.page-id-442 article>header.omb-page-header{display:none!important}
        body.page-id-442 main.site-main{padding-top:0!important}
        @media(max-width:900px){.omb-pge-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.omb-pge-form{grid-template-columns:1fr 1fr}.omb-pge-form button{width:100%}}
        @media(max-width:560px){.omb-pge-wrap{padding:0 12px 42px}.omb-pge-panel{padding:18px}.omb-pge-stats,.omb-pge-form{grid-template-columns:1fr}.omb-pge-value{font-size:23px}}
      </style>
      <div class="omb-pge-panel">
        <div class="omb-pge-kicker">1MBPUBLIC · MASTER TREASURY</div>
        <h2>Public Recipient Grants</h2>
        <p>Issue BOOST to a person who is not tied to a corporation. Every recipient remains inside the single 1MBPUBLIC lane and the canonical 50,000,000 BOOST Treasury.</p>
        <?php echo omb_pge_notice_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

        <div class="omb-pge-stats">
          <div class="omb-pge-stat"><div class="omb-pge-label">Public Pool Available</div><div class="omb-pge-value green"><?php echo esc_html(number_format($pool_coins, 4)); ?></div><div class="omb-pge-sub">BOOST available for grants</div></div>
          <div class="omb-pge-stat"><div class="omb-pge-label">Current Reference Value</div><div class="omb-pge-value"><?php echo esc_html(omb_pge_money($pool_value, 2)); ?></div><div class="omb-pge-sub">At verified market reference</div></div>
          <div class="omb-pge-stat"><div class="omb-pge-label">Verified Quote</div><div class="omb-pge-value"><?php echo esc_html(omb_pge_money($price, 8)); ?></div><div class="omb-pge-sub"><?php echo esc_html($source); ?></div></div>
          <div class="omb-pge-stat"><div class="omb-pge-label">Public Members</div><div class="omb-pge-value"><?php echo esc_html((string) count($members)); ?></div><div class="omb-pge-sub">Accounts tagged <?php echo esc_html(OMB_PGE_PUBLIC_CODE); ?></div></div>
        </div>

        <form class="omb-pge-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <input type="hidden" name="action" value="omb_pge_record_grant">
          <?php wp_nonce_field('omb_pge_record_grant', 'omb_pge_nonce'); ?>
          <label>Public Recipient
            <select name="recipient_user_id" required>
              <option value="">Choose a 1MBPUBLIC member</option>
              <?php foreach ($members as $member) : ?>
                <option value="<?php echo esc_attr((string) $member->ID); ?>"><?php echo esc_html($member->display_name . ' · ' . $member->user_email); ?></option>
              <?php endforeach; ?>
            </select>
          </label>
          <label>BOOST Amount
            <input type="number" name="coins" step="0.00000001" min="0.00000001" max="<?php echo esc_attr((string) $pool_coins); ?>" required>
          </label>
          <label>Grant Note
            <input type="text" name="note" maxlength="180" placeholder="Reason / reference">
          </label>
          <button type="submit">GRANT BOOST</button>
        </form>
        <div class="omb-pge-help">Need to add someone first? Send them to <a href="<?php echo esc_url(home_url('/rewards-signup/')); ?>">Public Rewards Signup</a>. Their account is automatically tagged <?php echo esc_html(OMB_PGE_PUBLIC_CODE); ?>.</div>

        <div class="omb-pge-history">
          <h3>Recent Public Grant Audit</h3>
          <?php if (!$recent) : ?>
            <div class="omb-pge-empty">No public grants recorded yet.</div>
          <?php else : ?>
            <div class="omb-pge-tablewrap"><table class="omb-pge-table"><thead><tr><th>Time</th><th>Recipient</th><th>BOOST</th><th>Reference Value</th><th>Pool Basis</th><th>Source</th><th>Note</th></tr></thead><tbody>
              <?php foreach ($recent as $grant) : ?>
                <tr>
                  <td><?php echo esc_html(isset($grant['time']) ? $grant['time'] : ''); ?></td>
                  <td><?php echo esc_html(isset($grant['recipient']) ? $grant['recipient'] : ''); ?></td>
                  <td><?php echo esc_html(number_format(isset($grant['coins']) ? (float) $grant['coins'] : 0, 4)); ?></td>
                  <td><?php echo esc_html(omb_pge_money(isset($grant['usd_value']) ? (float) $grant['usd_value'] : 0, 4)); ?></td>
                  <td><?php echo esc_html(omb_pge_money(isset($grant['pool_basis_usd']) ? (float) $grant['pool_basis_usd'] : 0, 4)); ?></td>
                  <td><?php echo esc_html(isset($grant['source']) ? $grant['source'] : ''); ?></td>
                  <td><?php echo esc_html(isset($grant['note']) ? $grant['note'] : ''); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody></table></div>
          <?php endif; ?>
        </div>
      </div>
    </section>
    <?php
    return ob_get_clean();
}

add_filter('do_shortcode_tag', function ($output, $tag, $attr, $m) {
    if ($tag !== 'omb_master_command_center') { return $output; }
    if (!is_user_logged_in() || !current_user_can('manage_options')) { return $output; }
    return $output . omb_pge_panel();
}, 20, 4);

add_action('admin_post_omb_pge_record_grant', function () {
    $back = home_url('/master-command-center/#public-grants');

    if (!is_user_logged_in() || !current_user_can('manage_options')) {
        wp_safe_redirect(wp_login_url($back));
        exit;
    }
    if (empty($_POST['omb_pge_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['omb_pge_nonce'])), 'omb_pge_record_grant')) {
        wp_safe_redirect(add_query_arg('omb_public_grant', 'security', $back));
        exit;
    }

    $recipient_id = isset($_POST['recipient_user_id']) ? absint($_POST['recipient_user_id']) : 0;
    $coins = isset($_POST['coins']) ? (float) wp_unslash($_POST['coins']) : 0.0;
    $note = isset($_POST['note']) ? sanitize_text_field(wp_unslash($_POST['note'])) : '';

    if ($coins <= 0) {
        wp_safe_redirect(add_query_arg('omb_public_grant', 'invalid_amount', $back));
        exit;
    }

    $member = get_userdata($recipient_id);
    $member_code = $recipient_id ? (string) get_user_meta($recipient_id, 'omb_company_code', true) : '';
    if (!$member || $member_code !== OMB_PGE_PUBLIC_CODE) {
        wp_safe_redirect(add_query_arg('omb_public_grant', 'invalid_recipient', $back));
        exit;
    }

    $pool = omb_pge_pool();
    $pool_coins = isset($pool['coins']) ? (float) $pool['coins'] : 0.0;
    if ($coins > $pool_coins + 0.000000001) {
        wp_safe_redirect(add_query_arg('omb_public_grant', 'insufficient_pool', $back));
        exit;
    }

    $quote = omb_pge_quote();
    $price = isset($quote['price']) ? (float) $quote['price'] : 0.0;
    if ($price <= 0) {
        wp_safe_redirect(add_query_arg('omb_public_grant', 'missing_quote', $back));
        exit;
    }

    $lots = isset($pool['lots']) && is_array($pool['lots']) ? $pool['lots'] : [];
    $basis = omb_pge_fifo_basis($lots, $coins);
    $now = current_time('mysql');
    $source = isset($quote['source']) ? sanitize_text_field((string) $quote['source']) : 'Verified reference';

    $grant = [
        'id' => wp_generate_uuid4(),
        'time' => $now,
        'coins' => $coins,
        'price' => $price,
        'usd_value' => $coins * $price,
        'pool_basis_usd' => (float) $basis['basis_usd'],
        'basis_uncovered_coins' => (float) $basis['uncovered_coins'],
        'source' => $source,
        'note' => $note,
        'granted_by' => get_current_user_id(),
        'user_id' => $recipient_id,
        'recipient' => $member->display_name,
        'email' => $member->user_email,
        'public_code' => OMB_PGE_PUBLIC_CODE,
        'source_treasury' => 'canonical_50m_master',
    ];

    $grants = get_option('omb_public_reward_grants_v1', []);
    if (!is_array($grants)) { $grants = []; }
    $grants[] = $grant;

    $pool['coins'] = max(0.0, $pool_coins - $coins);
    $pool['lots'] = $lots;
    $pool['updated_at'] = $now;

    update_option('omb_public_reward_grants_v1', $grants, false);
    update_option('omb_public_rewards_pool_v1', $pool, false);

    wp_safe_redirect(add_query_arg('omb_public_grant', 'success', $back));
    exit;
});
