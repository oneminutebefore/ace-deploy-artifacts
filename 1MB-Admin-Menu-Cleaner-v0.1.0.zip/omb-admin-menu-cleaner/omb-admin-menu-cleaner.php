<?php
/**
 * Plugin Name: 1MB Admin Menu Cleaner
 * Description: Keeps OneMinuteBefore admin navigation focused while preserving all underlying plugins and routes.
 * Version: 0.1.0
 * Author: ACE
 */

if (!defined('ABSPATH')) { exit; }

define('OMB_ADMIN_MENU_CLEANER_VERSION', '0.1.0');

add_action('admin_init', function () {
    update_option('omb_admin_menu_cleaner_version', OMB_ADMIN_MENU_CLEANER_VERSION, false);
});

add_action('admin_menu', function () {
    global $menu;
    if (!is_array($menu)) { return; }

    $hide = array(
        '1MB FitCoin',
        'Treasury Holdings',
        'Welcome Video',
    );

    $rename = array(
        '1MB Company Onboarding'   => 'Company Applications',
        'OMB Companies'            => 'Companies',
        '1MB Master Treasury'      => 'Master Treasury',
        '1MB HR Command Center'    => 'HR Command Center',
    );

    foreach ($menu as $key => &$item) {
        if (!is_array($item) || !isset($item[0])) { continue; }
        $label = trim(wp_strip_all_tags($item[0]));

        if (in_array($label, $hide, true)) {
            unset($menu[$key]);
            continue;
        }

        if (isset($rename[$label])) {
            $item[0] = $rename[$label];
        }
    }
    unset($item);
}, 999);
