OneMinuteBefore Employer Entry Points v0.1.3

Mobile redesign:
- Compact 2x2 navigation:
  Employers | Employees
  Public | Demo
- Employers is a single button.
- Tap Employers to reveal Employer Login and Employer Sign Up below it.
- Removes the oversized yellow-tile mobile look.
- Demo remains separate at /#demo.
- Desktop Employers dropdown stays unchanged.
