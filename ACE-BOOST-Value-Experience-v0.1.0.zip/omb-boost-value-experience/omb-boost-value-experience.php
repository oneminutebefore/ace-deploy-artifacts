<?php
/**
 * Plugin Name: 1MB BOOST Value Experience
 * Description: Read-only BOOST holdings and value cards for Master Treasury, company/HR, and employee reward views.
 * Version: 0.1.0
 * Author: ACE / One Minute Before
 */

if (!defined('ABSPATH')) {
    exit;
}

define('OMB_BVX_VERSION', '0.1.0');

register_activation_hook(__FILE__, function () {
    update_option('omb_boost_value_experience_version', OMB_BVX_VERSION, false);
});

function omb_bvx_num($value) {
    return is_numeric($value) ? (float) $value : 0.0;
}

function omb_bvx_quote() {
    $q = get_option('omb_boost_verified_quote_v1', array());
    if (!is_array($q)) {
        $q = array();
    }

    return array(
        'price' => isset($q['price']) ? omb_bvx_num($q['price']) : 0.0,
        'timestamp' => isset($q['timestamp']) ? (int) $q['timestamp'] : 0,
        'source' => !empty($q['source']) ? sanitize_text_field($q['source']) : 'Stored verified quote',
        'contract' => !empty($q['contract']) ? sanitize_text_field($q['contract']) : '',
    );
}

function omb_bvx_money($value, $decimals = 2) {
    return '$' . number_format_i18n((float) $value, $decimals);
}

function omb_bvx_boost($value) {
    $value = (float) $value;
    $decimals = abs($value - round($value)) < 0.00000001 ? 0 : 4;
    return number_format_i18n($value, $decimals);
}

function omb_bvx_price($value) {
    return '$' . number_format((float) $value, 8, '.', ',');
}

function omb_bvx_quote_meta($quote) {
    $parts = array();
    if (!empty($quote['source'])) {
        $parts[] = $quote['source'];
    }
    if (!empty($quote['timestamp'])) {
        $parts[] = wp_date('M j, Y g:i a T', (int) $quote['timestamp']);
    }
    return implode(' · ', $parts);
}

function omb_bvx_company_ledger() {
    $ledger = get_option('omb_boost_company_allocation_ledger_v1', array());
    return is_array($ledger) ? $ledger : array();
}

function omb_bvx_company_state($company_name) {
    $company_name = trim((string) $company_name);
    $ledger = omb_bvx_company_ledger();

    $current = 0.0;
    $acquired = 0.0;
    $basis = 0.0;
    $reset_seen = false;

    foreach ($ledger as $row) {
        if (!is_array($row) || empty($row['company_name'])) {
            continue;
        }
        if (strcasecmp(trim((string) $row['company_name']), $company_name) !== 0) {
            continue;
        }

        if (isset($row['after'])) {
            $current = max(0.0, omb_bvx_num($row['after']));
        }

        $type = isset($row['type']) ? (string) $row['type'] : '';
        $change = isset($row['change']) ? omb_bvx_num($row['change']) : 0.0;

        if ($type === 'internal_company_allocation_reset' || (isset($row['after']) && omb_bvx_num($row['after']) <= 0 && $change < 0)) {
            $acquired = 0.0;
            $basis = 0.0;
            $reset_seen = true;
            continue;
        }

        if ($change > 0) {
            $acquired += $change;
            if (isset($row['allocation_usd_value']) && omb_bvx_num($row['allocation_usd_value']) > 0) {
                $basis += omb_bvx_num($row['allocation_usd_value']);
            } elseif (isset($row['allocation_price']) && omb_bvx_num($row['allocation_price']) > 0) {
                $basis += $change * omb_bvx_num($row['allocation_price']);
            }
        }
    }

    if ($basis <= 0 && $current > 0) {
        $lots = get_option('omb_boost_company_purchase_lots_v1', array());
        if (is_array($lots)) {
            foreach ($lots as $lot) {
                if (!is_array($lot) || empty($lot['company_name'])) {
                    continue;
                }
                if (strcasecmp(trim((string) $lot['company_name']), $company_name) !== 0) {
                    continue;
                }
                $coins = isset($lot['boost_purchased']) ? omb_bvx_num($lot['boost_purchased']) : 0.0;
                $dollars = isset($lot['dollars_received']) ? omb_bvx_num($lot['dollars_received']) : 0.0;
                if ($coins > 0 && $dollars > 0) {
                    $acquired += $coins;
                    $basis += $dollars;
                }
            }
        }
    }

    $avg = ($acquired > 0 && $basis > 0) ? $basis / $acquired : 0.0;
    $remaining_basis = ($avg > 0 && $current > 0) ? $current * $avg : 0.0;

    return array(
        'company_name' => $company_name,
        'holdings' => $current,
        'acquired' => $acquired,
        'basis' => $remaining_basis,
        'avg_price' => $avg,
        'reset_seen' => $reset_seen,
    );
}

function omb_bvx_all_company_holdings() {
    $latest = array();
    foreach (omb_bvx_company_ledger() as $row) {
        if (!is_array($row) || empty($row['company_name']) || !isset($row['after'])) {
            continue;
        }
        $key = strtolower(trim((string) $row['company_name']));
        $latest[$key] = max(0.0, omb_bvx_num($row['after']));
    }
    return array_sum($latest);
}

function omb_bvx_public_commitment() {
    $pool = get_option('omb_public_rewards_pool_v1', array());
    if (!is_array($pool)) {
        return 0.0;
    }

    $lots = isset($pool['lots']) && is_array($pool['lots']) ? $pool['lots'] : array();
    $funded = 0.0;
    foreach ($lots as $lot) {
        if (is_array($lot) && isset($lot['coins'])) {
            $funded += max(0.0, omb_bvx_num($lot['coins']));
        }
    }

    if ($funded <= 0 && isset($pool['coins'])) {
        $funded = max(0.0, omb_bvx_num($pool['coins']));
    }

    return $funded;
}

function omb_bvx_master_state() {
    $canonical = omb_bvx_num(get_option('omb_boost_master_treasury_canonical_total_v1', 0));
    if ($canonical <= 0) {
        $canonical = omb_bvx_num(get_option('omb_boost_master_treasury_inventory', 0));
    }

    $company = omb_bvx_all_company_holdings();
    $public = omb_bvx_public_commitment();
    $available = max(0.0, $canonical - $company - $public);

    return array(
        'canonical' => $canonical,
        'company_committed' => $company,
        'public_committed' => $public,
        'total_committed' => $company + $public,
        'available' => $available,
    );
}

function omb_bvx_employee_state($user_id) {
    global $wpdb;

    $user_id = (int) $user_id;
    $boost = 0.0;
    $reward_basis = 0.0;
    $count = 0;

    if ($user_id > 0) {
        $table = $wpdb->prefix . 'omb_boost_reward_snapshots';
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if ($exists === $table) {
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT COALESCE(SUM(boost_equivalent),0) AS boost_total, COALESCE(SUM(reward_usd),0) AS reward_total, COUNT(*) AS reward_count FROM {$table} WHERE user_id = %d",
                    $user_id
                ),
                ARRAY_A
            );
            if (is_array($row)) {
                $boost = omb_bvx_num($row['boost_total']);
                $reward_basis = omb_bvx_num($row['reward_total']);
                $count = isset($row['reward_count']) ? (int) $row['reward_count'] : 0;
            }
        }
    }

    if ($boost <= 0) {
        $ledger = get_user_meta($user_id, 'omb_boost_reward_ledger_v1', true);
        if (is_array($ledger)) {
            foreach ($ledger as $entry) {
                if (!is_array($entry)) {
                    continue;
                }
                $boost += isset($entry['boost']) ? omb_bvx_num($entry['boost']) : 0.0;
                $reward_basis += isset($entry['reward_usd']) ? omb_bvx_num($entry['reward_usd']) : 0.0;
                $count++;
            }
        }
    }

    return array(
        'boost' => $boost,
        'reward_basis' => $reward_basis,
        'count' => $count,
    );
}

function omb_bvx_styles() {
    static $done = false;
    if ($done) {
        return '';
    }
    $done = true;

    return '<style>
    .omb-bvx{max-width:1180px;margin:18px auto 24px;padding:0 18px;color:#fff;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
    .omb-bvx *{box-sizing:border-box}.omb-bvx-panel{background:linear-gradient(145deg,#07131d,#0d2230);border:1px solid #2a4658;border-radius:22px;padding:22px;box-shadow:0 18px 50px rgba(0,0,0,.16)}
    .omb-bvx-top{display:flex;justify-content:space-between;gap:14px;align-items:flex-end;flex-wrap:wrap;margin-bottom:16px}.omb-bvx-kicker{font-size:11px;letter-spacing:.15em;text-transform:uppercase;color:#b7ff36;font-weight:950}.omb-bvx h2{margin:6px 0 0;color:#fff;font-size:clamp(25px,4vw,36px);line-height:1.05}.omb-bvx-quote{font-size:12px;color:#9eb2c0;text-align:right}.omb-bvx-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.omb-bvx-card{background:#0a1822;border:1px solid #294151;border-radius:16px;padding:17px;min-width:0}.omb-bvx-label{display:block;color:#8da4b3;font-size:10px;text-transform:uppercase;letter-spacing:.09em;font-weight:900}.omb-bvx-value{display:block;color:#fff;font-size:clamp(22px,3vw,30px);font-weight:950;line-height:1.1;margin-top:6px;word-break:break-word}.omb-bvx-value.good{color:#b7ff36}.omb-bvx-value.warn{color:#ffd477}.omb-bvx-note{margin:14px 0 0;color:#8fa6b5;font-size:12px;line-height:1.5}.omb-bvx-change{font-weight:950}.omb-bvx-change.pos{color:#b7ff36}.omb-bvx-change.neg{color:#ffbd8a}.omb-bvx-sub{display:block;color:#78909f;font-size:11px;margin-top:5px;line-height:1.35}
    @media(max-width:800px){.omb-bvx-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.omb-bvx-quote{text-align:left}}
    @media(max-width:520px){.omb-bvx{padding:0 12px}.omb-bvx-panel{padding:18px 14px}.omb-bvx-grid{grid-template-columns:1fr}.omb-bvx-value{font-size:27px}}
    </style>';
}

function omb_bvx_change_html($delta, $basis) {
    $class = $delta >= 0 ? 'pos' : 'neg';
    $sign = $delta >= 0 ? '+' : '';
    $pct = ($basis > 0) ? ($delta / $basis) * 100 : 0;
    return '<span class="omb-bvx-change ' . esc_attr($class) . '">' . esc_html($sign . omb_bvx_money($delta) . ' (' . $sign . number_format_i18n($pct, 2) . '%)') . '</span>';
}

function omb_bvx_render_master() {
    $m = omb_bvx_master_state();
    $q = omb_bvx_quote();
    $price = $q['price'];
    $canonical_value = $m['canonical'] * $price;
    $available_value = $m['available'] * $price;

    $html = omb_bvx_styles();
    $html .= '<section class="omb-bvx"><div class="omb-bvx-panel">';
    $html .= '<div class="omb-bvx-top"><div><span class="omb-bvx-kicker">BOOST TREASURY VALUE</span><h2>Canonical Treasury Snapshot</h2></div><div class="omb-bvx-quote">Reference: ' . esc_html(omb_bvx_quote_meta($q)) . '</div></div>';
    $html .= '<div class="omb-bvx-grid">';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Canonical Treasury</span><span class="omb-bvx-value good">' . esc_html(omb_bvx_boost($m['canonical'])) . '</span><span class="omb-bvx-sub">BOOST accounting source</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Available Treasury</span><span class="omb-bvx-value">' . esc_html(omb_bvx_boost($m['available'])) . '</span><span class="omb-bvx-sub">After company and public commitments</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Verified Reference Price</span><span class="omb-bvx-value">' . esc_html(omb_bvx_price($price)) . '</span><span class="omb-bvx-sub">Market/reference value only</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Canonical Market Value</span><span class="omb-bvx-value">' . esc_html(omb_bvx_money($canonical_value)) . '</span><span class="omb-bvx-sub">50M × verified quote</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Available Market Value</span><span class="omb-bvx-value">' . esc_html(omb_bvx_money($available_value)) . '</span><span class="omb-bvx-sub">Uncommitted Treasury at reference quote</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Committed BOOST</span><span class="omb-bvx-value">' . esc_html(omb_bvx_boost($m['total_committed'])) . '</span><span class="omb-bvx-sub">Companies ' . esc_html(omb_bvx_boost($m['company_committed'])) . ' · Public ' . esc_html(omb_bvx_boost($m['public_committed'])) . '</span></div>';
    $html .= '</div><p class="omb-bvx-note">Accounting remains anchored to the canonical 50,000,000 BOOST Treasury. Connected wallet or chain balances are not used to calculate Treasury inventory.</p>';
    $html .= '</div></section>';
    return $html;
}

function omb_bvx_render_company($user_id) {
    $company_name = get_user_meta($user_id, 'omb_company_name', true);
    if (!$company_name) {
        $company_name = get_user_meta($user_id, 'omb_corporate_company_name', true);
    }
    if (!$company_name) {
        return '';
    }

    $state = omb_bvx_company_state($company_name);
    $q = omb_bvx_quote();
    $market = $state['holdings'] * $q['price'];
    $delta = $market - $state['basis'];

    $html = omb_bvx_styles();
    $html .= '<section class="omb-bvx"><div class="omb-bvx-panel">';
    $html .= '<div class="omb-bvx-top"><div><span class="omb-bvx-kicker">COMPANY BOOST VALUE</span><h2>' . esc_html($company_name) . ' Holdings</h2></div><div class="omb-bvx-quote">Reference: ' . esc_html(omb_bvx_quote_meta($q)) . '</div></div>';
    $html .= '<div class="omb-bvx-grid">';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">BOOST Held</span><span class="omb-bvx-value good">' . esc_html(omb_bvx_boost($state['holdings'])) . '</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Acquisition Basis</span><span class="omb-bvx-value">' . esc_html(omb_bvx_money($state['basis'])) . '</span><span class="omb-bvx-sub">Recorded company acquisition value</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Average Acquisition Price</span><span class="omb-bvx-value">' . esc_html(omb_bvx_price($state['avg_price'])) . '</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Current Reference Price</span><span class="omb-bvx-value">' . esc_html(omb_bvx_price($q['price'])) . '</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Current Market Value</span><span class="omb-bvx-value">' . esc_html(omb_bvx_money($market)) . '</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Change vs Acquisition Basis</span><span class="omb-bvx-value">' . omb_bvx_change_html($delta, $state['basis']) . '</span></div>';
    $html .= '</div><p class="omb-bvx-note">Acquisition basis comes from recorded company allocation or purchase events after the latest reset. Current market value uses the verified BOOST reference quote and does not rewrite the company purchase price.</p>';
    $html .= '</div></section>';
    return $html;
}

function omb_bvx_render_employee($user_id) {
    $s = omb_bvx_employee_state($user_id);
    $q = omb_bvx_quote();
    $market = $s['boost'] * $q['price'];
    $delta = $market - $s['reward_basis'];

    $html = omb_bvx_styles();
    $html .= '<section class="omb-bvx"><div class="omb-bvx-panel">';
    $html .= '<div class="omb-bvx-top"><div><span class="omb-bvx-kicker">MY BOOST VALUE</span><h2>Your BOOST Holdings</h2></div><div class="omb-bvx-quote">Reference: ' . esc_html(omb_bvx_quote_meta($q)) . '</div></div>';
    $html .= '<div class="omb-bvx-grid">';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">BOOST Earned</span><span class="omb-bvx-value good">' . esc_html(omb_bvx_boost($s['boost'])) . '</span><span class="omb-bvx-sub">Across ' . esc_html(number_format_i18n($s['count'])) . ' reward event(s)</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Reward Basis</span><span class="omb-bvx-value">' . esc_html(omb_bvx_money($s['reward_basis'])) . '</span><span class="omb-bvx-sub">USD reward value when earned</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Current Reference Price</span><span class="omb-bvx-value">' . esc_html(omb_bvx_price($q['price'])) . '</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Current Market Value</span><span class="omb-bvx-value">' . esc_html(omb_bvx_money($market)) . '</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Change vs Reward Basis</span><span class="omb-bvx-value">' . omb_bvx_change_html($delta, $s['reward_basis']) . '</span></div>';
    $html .= '<div class="omb-bvx-card"><span class="omb-bvx-label">Quote Source</span><span class="omb-bvx-value" style="font-size:20px">' . esc_html($q['source']) . '</span><span class="omb-bvx-sub">Stored verified quote</span></div>';
    $html .= '</div><p class="omb-bvx-note">Reward basis is the recorded USD reward amount at the time BOOST was earned. The reference value can move with the market and is informational, not tax guidance.</p>';
    $html .= '</div></section>';
    return $html;
}

function omb_bvx_filter_content($content) {
    if (is_admin() || !is_singular('page')) {
        return $content;
    }

    global $post;
    if (!$post || empty($post->post_name)) {
        return $content;
    }

    $slug = (string) $post->post_name;

    if ($slug === 'master-command-center' && is_user_logged_in() && current_user_can('manage_options')) {
        return omb_bvx_render_master() . $content;
    }

    if (($slug === 'hr-command-center' || $slug === 'company-command-center') && is_user_logged_in()) {
        $company = omb_bvx_render_company(get_current_user_id());
        if ($company) {
            return $company . $content;
        }
    }

    if ($slug === 'my-rewards' && is_user_logged_in()) {
        return omb_bvx_render_employee(get_current_user_id()) . $content;
    }

    return $content;
}
add_filter('the_content', 'omb_bvx_filter_content', 99);
