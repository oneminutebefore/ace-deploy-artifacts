<?php
/**
 * Plugin Name: 1MB Public Grant Recipient Sync
 * Description: Mirrors canonical 1MBPUBLIC Treasury grants into each recipient's personal grant ledger.
 * Version: 0.1.0
 * Author: ACE
 */
if (!defined('ABSPATH')) { exit; }

function omb_pgrs_sync() {
    $grants = get_option('omb_public_reward_grants_v1', []);
    if (!is_array($grants)) { return; }
    foreach ($grants as $grant) {
        if (!is_array($grant) || empty($grant['id']) || empty($grant['user_id'])) { continue; }
        $uid = absint($grant['user_id']);
        if (!$uid || (string) get_user_meta($uid, 'omb_company_code', true) !== '1MBPUBLIC') { continue; }
        $ledger = get_user_meta($uid, 'omb_public_boost_grants_v1', true);
        if (!is_array($ledger)) { $ledger = []; }
        $found = false;
        foreach ($ledger as $entry) {
            if (is_array($entry) && !empty($entry['id']) && (string) $entry['id'] === (string) $grant['id']) { $found = true; break; }
        }
        if ($found) { continue; }
        $ledger[] = [
            'id' => (string) $grant['id'],
            'time' => isset($grant['time']) ? (string) $grant['time'] : current_time('mysql'),
            'coins' => isset($grant['coins']) ? (float) $grant['coins'] : 0.0,
            'price' => isset($grant['price']) ? (float) $grant['price'] : 0.0,
            'usd_value' => isset($grant['usd_value']) ? (float) $grant['usd_value'] : 0.0,
            'pool_basis_usd' => isset($grant['pool_basis_usd']) ? (float) $grant['pool_basis_usd'] : 0.0,
            'basis_uncovered_coins' => isset($grant['basis_uncovered_coins']) ? (float) $grant['basis_uncovered_coins'] : 0.0,
            'source' => isset($grant['source']) ? (string) $grant['source'] : '',
            'note' => isset($grant['note']) ? (string) $grant['note'] : '',
            'granted_by' => isset($grant['granted_by']) ? absint($grant['granted_by']) : 0,
        ];
        update_user_meta($uid, 'omb_public_boost_grants_v1', $ledger);
    }
}

register_activation_hook(__FILE__, function () {
    update_option('omb_public_grant_recipient_sync_version', '0.1.0', false);
    omb_pgrs_sync();
});

add_action('updated_option', function ($option) {
    if ($option === 'omb_public_reward_grants_v1') { omb_pgrs_sync(); }
}, 10, 1);
