<?php
/**
 * Plugin Name: 1MB Company Signup Cache Guard
 * Description: Keeps the public company application page uncached so its WordPress security nonce stays fresh while preserving the existing onboarding and approval workflow.
 * Version: 0.1.0
 * Author: ACE
 */
if (!defined('ABSPATH')) exit;

function omb_cscg_is_company_signup() {
    return is_page(223) || is_page('company-signup');
}

function omb_cscg_disable_cache() {
    if (!omb_cscg_is_company_signup()) return;

    if (!defined('DONOTCACHEPAGE')) {
        define('DONOTCACHEPAGE', true);
    }

    if (function_exists('nocache_headers')) {
        nocache_headers();
    }

    // LiteSpeed Cache public no-cache control hook.
    do_action('litespeed_control_set_nocache', '1MB company signup requires a fresh security nonce');
}
add_action('template_redirect', 'omb_cscg_disable_cache', 0);
