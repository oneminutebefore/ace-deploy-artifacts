<?php
/**
 * Plugin Name: 1MB Demo Request Guard
 * Description: Reliable public Request a Demo handling for OneMinuteBefore without cached nonce failures.
 * Version: 0.1.0
 * Author: ACE
 */
if (!defined('ABSPATH')) exit;

function omb_drg_redirect($status){
    wp_safe_redirect(add_query_arg('demo', sanitize_key($status), home_url('/')) . '#demo');
    exit;
}

function omb_drg_handle_demo(){
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? '')) !== 'POST') {
        omb_drg_redirect('error');
    }

    $name      = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
    $email     = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $company   = sanitize_text_field(wp_unslash($_POST['company'] ?? ''));
    $employees = sanitize_text_field(wp_unslash($_POST['employees'] ?? ''));
    $message   = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));

    if ($name === '' || !is_email($email)) {
        omb_drg_redirect('invalid');
    }

    $ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $rate_key = 'omb_drg_' . md5(strtolower($email) . '|' . $ip);
    if (get_transient($rate_key)) {
        omb_drg_redirect('slow');
    }
    set_transient($rate_key, 1, MINUTE_IN_SECONDS);

    $to      = get_option('admin_email');
    $subject = 'ONE MINUTE BEFORE DEMO REQUEST | ' . $name;
    $body    = "Name: {$name}\nEmail: {$email}\nCompany: {$company}\nEmployees: {$employees}\nMessage: {$message}";
    $headers = ['Reply-To: ' . $name . ' <' . $email . '>'];

    if (!wp_mail($to, $subject, $body, $headers)) {
        delete_transient($rate_key);
        omb_drg_redirect('error');
    }

    omb_drg_redirect('sent');
}
add_action('admin_post_nopriv_omb_demo', 'omb_drg_handle_demo', 1);
add_action('admin_post_omb_demo', 'omb_drg_handle_demo', 1);

function omb_drg_feedback(){
    if (!is_front_page()) return;
    $status = sanitize_key(wp_unslash($_GET['demo'] ?? ''));
    if (!in_array($status, ['sent','invalid','slow','error'], true)) return;

    $messages = [
        'sent'    => ['Thanks. Your demo request was sent.', 'We received your information and will follow up shortly.'],
        'invalid' => ['Please check the form.', 'Enter your name and a valid work email, then try again.'],
        'slow'    => ['Request already received.', 'Please wait a moment before submitting another request.'],
        'error'   => ['We could not send that request.', 'Please try again in a moment.'],
    ];
    [$title,$copy] = $messages[$status];
    ?>
    <style>
      .omb-drg-feedback{margin:0 0 16px;padding:14px 16px;border:1px solid #344754;border-radius:12px;background:#0c171f;color:#fff}
      .omb-drg-feedback strong{display:block;margin-bottom:3px;color:#b6ff21}
      .omb-drg-feedback span{color:#a7b6c0;font-size:13px}
    </style>
    <script>
    document.addEventListener('DOMContentLoaded',function(){
      var form=document.querySelector('#demo .ombx-form');
      if(!form) return;
      var box=document.createElement('div');
      box.className='omb-drg-feedback';
      box.innerHTML='<strong><?php echo esc_js($title); ?></strong><span><?php echo esc_js($copy); ?></span>';
      form.parentNode.insertBefore(box,form);
    });
    </script>
    <?php
}
add_action('wp_footer','omb_drg_feedback',50);
