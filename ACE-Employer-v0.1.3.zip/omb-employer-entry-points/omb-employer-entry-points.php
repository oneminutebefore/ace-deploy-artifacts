<?php
/**
 * Plugin Name: 1MB Employer Entry Points
 * Description: Compact employer navigation with polished mobile menu.
 * Version: 0.1.3
 * Author: One Minute Before
 */
if (!defined('ABSPATH')) exit;

function omb_eep_login_url(){ return home_url('/company-login/'); }
function omb_eep_signup_url(){ return home_url('/company-signup/'); }

add_action('wp_head', function(){ ?>
<style id="omb-eep-css">
.omb-eep-wrap{position:relative;display:inline-flex;align-items:center}
.omb-eep-trigger{display:inline-flex!important;align-items:center!important;gap:6px!important}
.omb-eep-trigger:after{content:"▾";font-size:10px;opacity:.8}
.omb-eep-menu{position:absolute;top:calc(100% + 8px);left:0;z-index:999999;min-width:185px;padding:8px;background:#09131a;border:1px solid #304654;border-radius:14px;box-shadow:0 18px 45px rgba(0,0,0,.35);opacity:0;visibility:hidden;transform:translateY(-4px);transition:.16s ease}
.omb-eep-wrap:hover .omb-eep-menu,.omb-eep-wrap:focus-within .omb-eep-menu,.omb-eep-wrap.is-open .omb-eep-menu{opacity:1;visibility:visible;transform:none}
.omb-eep-menu a{display:flex!important;align-items:center!important;min-height:40px!important;padding:0 12px!important;border-radius:9px!important;color:#fff!important;text-decoration:none!important;font-size:12px!important;font-weight:900!important;white-space:nowrap!important}
.omb-eep-menu a.omb-eep-signup{margin-top:4px!important;background:#b6ff21!important;color:#071007!important}

.omb-eep-company-cta{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:20px}
.omb-eep-company-cta a{display:inline-flex;min-height:46px;align-items:center;justify-content:center;padding:0 17px;border-radius:12px;text-decoration:none!important;font-weight:950;font-size:12px}
.omb-eep-company-cta .primary{background:#b6ff21;border:1px solid #b6ff21;color:#071007!important}
.omb-eep-company-cta .secondary{background:#102330;border:1px solid #365365;color:#fff!important}
.omb-eep-company-note{width:100%;margin-top:2px;color:#a6b5be;font-size:11px;line-height:1.45}

@media(max-width:900px){
  .omb-eep-wrap{display:none!important}
  .ombx-nav{display:block!important;padding:16px 18px 14px!important}
  .ombx-brand{display:flex!important;align-items:center!important;margin-bottom:14px!important}
  .ombx-brand .ombx-mark{width:62px!important;height:62px!important;min-width:62px!important}
  .ombx-brand b{font-size:21px!important;line-height:1.05!important}
  .ombx-brand small{font-size:12px!important;margin-top:5px!important}

  .ombx-mobile{
    display:grid!important;
    grid-template-columns:repeat(2,minmax(0,1fr))!important;
    gap:8px!important;
    width:100%!important;
    margin:0!important;
    padding:0!important;
  }
  .ombx-mobile > a,.ombx-mobile > .omb-eep-mobile-wrap{min-width:0!important;width:100%!important;margin:0!important}
  .ombx-mobile > a{
    display:flex!important;align-items:center!important;justify-content:center!important;
    min-height:48px!important;padding:8px 10px!important;border-radius:12px!important;
    border:1px solid #263746!important;background:#0b151d!important;color:#fff!important;
    font-size:13px!important;line-height:1.1!important;font-weight:900!important;
    text-align:center!important;text-decoration:none!important;box-shadow:none!important;
  }
  .ombx-mobile > a:last-child{background:#ffd400!important;border-color:#ffd400!important;color:#080808!important}

  .omb-eep-mobile-wrap{position:relative!important;display:block!important}
  .omb-eep-mobile-label{
    appearance:none!important;-webkit-appearance:none!important;width:100%!important;min-height:48px!important;
    padding:8px 10px!important;border-radius:12px!important;border:1px solid #263746!important;
    background:#0b151d!important;color:#fff!important;font:inherit!important;font-size:13px!important;
    line-height:1.1!important;font-weight:900!important;text-align:center!important;cursor:pointer!important;
  }
  .omb-eep-mobile-label:after{content:" ▾";color:#ffd400;font-size:10px}
  .omb-eep-mobile-sub{
    position:absolute!important;top:calc(100% + 6px)!important;left:0!important;z-index:999999!important;
    width:100%!important;min-width:170px!important;display:none!important;grid-template-columns:1fr!important;
    gap:5px!important;padding:7px!important;border:1px solid #304654!important;border-radius:12px!important;
    background:#09131a!important;box-shadow:0 18px 45px rgba(0,0,0,.42)!important;
  }
  .omb-eep-mobile-wrap.is-open .omb-eep-mobile-sub{display:grid!important}
  .omb-eep-mobile-sub a{
    display:flex!important;align-items:center!important;justify-content:center!important;
    min-height:39px!important;padding:7px 10px!important;border-radius:8px!important;
    text-decoration:none!important;font-size:11px!important;line-height:1.15!important;font-weight:900!important;text-align:center!important;
  }
  .omb-eep-mobile-sub a:first-child{background:#12212b!important;color:#fff!important;border:1px solid #304654!important}
  .omb-eep-mobile-sub a:last-child{background:#b6ff21!important;color:#071007!important;border:1px solid #b6ff21!important}
}
@media(max-width:560px){
  .omb-eep-company-cta{display:grid;grid-template-columns:1fr}
  .omb-eep-company-cta a{width:100%}
}
</style>
<?php },40);

add_action('wp_footer', function(){
$login=esc_url(omb_eep_login_url());
$signup=esc_url(omb_eep_signup_url());
?>
<script id="omb-eep-js">
(function(){
 var login=<?php echo wp_json_encode($login); ?>, signup=<?php echo wp_json_encode($signup); ?>;
 function link(t,h,c){var a=document.createElement('a');a.href=h;a.textContent=t;if(c)a.className=c;return a;}

 function desktop(){
  var nav=document.querySelector('.ombx-menu'); if(!nav||nav.querySelector('.omb-eep-wrap'))return;
  [].slice.call(nav.querySelectorAll(':scope > a.omb-eep-signup')).forEach(function(n){n.remove();});
  var old=[].slice.call(nav.querySelectorAll(':scope > a')).find(function(a){return (a.href||'').replace(/\/+$/,'')===login.replace(/\/+$/,'');});
  if(!old)return;
  var wrap=document.createElement('span');wrap.className='omb-eep-wrap';
  var trigger=link('Employers',login,'omb-eep-trigger');trigger.setAttribute('aria-haspopup','true');trigger.setAttribute('aria-expanded','false');
  var menu=document.createElement('span');menu.className='omb-eep-menu';
  menu.appendChild(link('Employer Login',login,''));menu.appendChild(link('Employer Sign Up',signup,'omb-eep-signup'));
  wrap.appendChild(trigger);wrap.appendChild(menu);old.parentNode.replaceChild(wrap,old);
 }

 function wireMobileToggle(wrap){
  if(wrap.getAttribute('data-eep-wired')==='1')return;
  wrap.setAttribute('data-eep-wired','1');
  var button=wrap.querySelector('.omb-eep-mobile-label'); if(!button)return;
  button.addEventListener('click',function(e){e.preventDefault();var open=wrap.classList.toggle('is-open');button.setAttribute('aria-expanded',open?'true':'false');});
  document.addEventListener('click',function(e){if(!wrap.contains(e.target)){wrap.classList.remove('is-open');button.setAttribute('aria-expanded','false');}});
 }

 function mobile(){
  var nav=document.querySelector('.ombx-mobile'); if(!nav)return;
  var existing=nav.querySelector('.omb-eep-mobile-wrap');
  if(existing){wireMobileToggle(existing);return;}
  [].slice.call(nav.querySelectorAll(':scope > a.omb-eep-signup')).forEach(function(n){n.remove();});
  var old=[].slice.call(nav.querySelectorAll(':scope > a')).find(function(a){return (a.href||'').replace(/\/+$/,'')===login.replace(/\/+$/,'');});
  if(!old)return;
  var wrap=document.createElement('div');wrap.className='omb-eep-mobile-wrap';
  var label=document.createElement('button');label.type='button';label.className='omb-eep-mobile-label';label.textContent='Employers';label.setAttribute('aria-expanded','false');
  var sub=document.createElement('div');sub.className='omb-eep-mobile-sub';
  sub.appendChild(link('Employer Login',login,''));sub.appendChild(link('Employer Sign Up',signup,''));
  wrap.appendChild(label);wrap.appendChild(sub);old.parentNode.replaceChild(wrap,old);wireMobileToggle(wrap);
 }

 function companyCTA(){
  var section=document.querySelector('.ombx-employers'); if(!section||section.querySelector('.omb-eep-company-cta'))return;
  var head=section.querySelector('.ombx-employer-head > div')||section.querySelector('.ombx-employer-head')||section.querySelector('.wrap'); if(!head)return;
  var box=document.createElement('div');box.className='omb-eep-company-cta';
  box.appendChild(link('START EMPLOYER SIGNUP',signup,'primary'));box.appendChild(link('EMPLOYER LOGIN',login,'secondary'));
  var note=document.createElement('div');note.className='omb-eep-company-note';note.textContent='New company? Submit the short application. Already approved? Use Employer Login.';
  box.appendChild(note);head.appendChild(box);
 }

 function boot(){desktop();mobile();companyCTA();}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
 setTimeout(boot,300);setTimeout(boot,1200);
})();
</script>
<?php },100);
